#include <Wire.h>

#define LED_PIN       13
#define BUZZER_PIN    8

#define MPU_ADDR      0x68
#define ACCEL_XOUT_H  0x3B
#define ACCEL_SCALE   16384.0f
#define GYRO_SCALE    131.0f

#define EMA_ALPHA       0.02f
#define TILT_SIGMA_MULT 3.0f
#define VIB_SIGMA_MULT  3.5f
#define CALIB_SAMPLES   200
#define FREEFALL_THRESH 0.3f

typedef enum {
  FAULT_NONE      = 0,
  FAULT_TILT      = 1,
  FAULT_VIBRATION = 2,
  FAULT_FREEFALL  = 3
} FaultState;

const char* FAULT_LABELS[] = {
  "NORMAL", "TILT_WARNING", "VIBRATION_FAULT", "FREE_FALL_DETECTED"
};

float ax, ay, az;
float gx, gy, gz;
float roll, pitch;
float gyro_mag;
float accel_mag;

float ema_roll      = 0;
float ema_pitch     = 0;
float ema_gyro_mag  = 0;

float var_roll      = 0;
float var_pitch     = 0;
float var_gyro_mag  = 0;
float m2_roll       = 0;
float m2_pitch      = 0;
float m2_gyro_mag   = 0;

unsigned long sample_count = 0;
FaultState current_fault   = FAULT_NONE;
FaultState last_fault      = FAULT_NONE;

unsigned long last_blink_ms = 0;
bool led_state              = false;

void mpu_init() {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x6B);
  Wire.write(0x00);
  Wire.endTransmission(true);
  delay(100);

  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x1A);
  Wire.write(0x03);
  Wire.endTransmission(true);

  Serial.println("MPU-6050 initialized.");
}

void mpu_read() {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(ACCEL_XOUT_H);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU_ADDR, 14, true);

  int16_t raw_ax = (Wire.read() << 8) | Wire.read();
  int16_t raw_ay = (Wire.read() << 8) | Wire.read();
  int16_t raw_az = (Wire.read() << 8) | Wire.read();
  Wire.read(); Wire.read();
  int16_t raw_gx = (Wire.read() << 8) | Wire.read();
  int16_t raw_gy = (Wire.read() << 8) | Wire.read();
  int16_t raw_gz = (Wire.read() << 8) | Wire.read();

  ax = raw_ax / ACCEL_SCALE;
  ay = raw_ay / ACCEL_SCALE;
  az = raw_az / ACCEL_SCALE;
  gx = raw_gx / GYRO_SCALE;
  gy = raw_gy / GYRO_SCALE;
  gz = raw_gz / GYRO_SCALE;

  roll      = atan2(ay, az) * 57.2958;
  pitch     = atan2(-ax, sqrt(ay*ay + az*az)) * 57.2958;
  gyro_mag  = sqrt(gx*gx + gy*gy + gz*gz);
  accel_mag = sqrt(ax*ax + ay*ay + az*az);
}

void update_baseline() {
  float n = (float)sample_count;

  ema_roll     = EMA_ALPHA * roll      + (1.0 - EMA_ALPHA) * ema_roll;
  ema_pitch    = EMA_ALPHA * pitch     + (1.0 - EMA_ALPHA) * ema_pitch;
  ema_gyro_mag = EMA_ALPHA * gyro_mag  + (1.0 - EMA_ALPHA) * ema_gyro_mag;

  float delta_roll = roll - ema_roll;
  m2_roll += delta_roll * delta_roll;
  if (n > 1) var_roll = m2_roll / (n - 1);

  float delta_pitch = pitch - ema_pitch;
  m2_pitch += delta_pitch * delta_pitch;
  if (n > 1) var_pitch = m2_pitch / (n - 1);

  float delta_gyro = gyro_mag - ema_gyro_mag;
  m2_gyro_mag += delta_gyro * delta_gyro;
  if (n > 1) var_gyro_mag = m2_gyro_mag / (n - 1);

  m2_roll     *= 0.9995;
  m2_pitch    *= 0.9995;
  m2_gyro_mag *= 0.9995;
}

FaultState classify_fault() {
  if (accel_mag < FREEFALL_THRESH) return FAULT_FREEFALL;

  float std_roll     = sqrt(var_roll);
  float std_pitch    = sqrt(var_pitch);
  float std_gyro_mag = sqrt(var_gyro_mag);

  float tilt_deviation = max(
    abs(roll  - ema_roll),
    abs(pitch - ema_pitch)
  );
  float tilt_threshold = TILT_SIGMA_MULT * max(std_roll, std_pitch);

  float vib_deviation = abs(gyro_mag - ema_gyro_mag);
  float vib_threshold = VIB_SIGMA_MULT * std_gyro_mag;

  if (vib_deviation > vib_threshold && vib_threshold > 0.5) return FAULT_VIBRATION;
  if (tilt_deviation > tilt_threshold && tilt_threshold > 1.0) return FAULT_TILT;

  return FAULT_NONE;
}

void buzz(int freq, int dur_ms) {
  tone(BUZZER_PIN, freq, dur_ms);
  delay(dur_ms);
  noTone(BUZZER_PIN);
}

void handle_outputs(FaultState fault) {
  unsigned long now = millis();

  switch (fault) {
    case FAULT_NONE:
      digitalWrite(LED_PIN, LOW);
      noTone(BUZZER_PIN);
      break;

    case FAULT_TILT:
      if (now - last_blink_ms > 500) {
        led_state = !led_state;
        digitalWrite(LED_PIN, led_state);
        last_blink_ms = now;
      }
      if (now % 2000 < 20) buzz(800, 80);
      break;

    case FAULT_VIBRATION:
      if (now - last_blink_ms > 150) {
        led_state = !led_state;
        digitalWrite(LED_PIN, led_state);
        last_blink_ms = now;
      }
      if (now % 1000 < 20)  buzz(1200, 60);
      if (now % 1000 > 100 && now % 1000 < 120) buzz(1200, 60);
      break;

    case FAULT_FREEFALL:
      digitalWrite(LED_PIN, HIGH);
      tone(BUZZER_PIN, 2000);
      break;
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Wire.begin();
  mpu_init();

  Serial.println("=== Motion & Tilt Fault Detection ===");
  Serial.print("Calibrating over ");
  Serial.print(CALIB_SAMPLES);
  Serial.println(" samples...");

  buzz(1000, 100);
  delay(100);
  buzz(1500, 100);
}

void loop() {
  mpu_read();
  sample_count++;
  update_baseline();

  if (sample_count > CALIB_SAMPLES) {
    current_fault = classify_fault();
  } else {
    current_fault = FAULT_NONE;
    if (sample_count % 50 == 0) {
      Serial.print("Calibrating... ");
      Serial.print(sample_count);
      Serial.print("/");
      Serial.println(CALIB_SAMPLES);
    }
  }

  handle_outputs(current_fault);

  if (sample_count % 10 == 0) {
    Serial.print("Roll:");
    Serial.print(roll, 1);
    Serial.print(" Pitch:");
    Serial.print(pitch, 1);
    Serial.print(" Gyro:");
    Serial.print(gyro_mag, 1);
    Serial.print(" | ");
    Serial.println(FAULT_LABELS[current_fault]);
  }

  if (current_fault != last_fault) {
    Serial.print(">>> FAULT: ");
    Serial.println(FAULT_LABELS[current_fault]);
    last_fault = current_fault;
  }

  delay(10);
}